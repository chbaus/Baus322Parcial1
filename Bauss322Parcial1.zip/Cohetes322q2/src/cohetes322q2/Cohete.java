package cohetes322q2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

public class Cohete implements Aprobable {

    private final int id;
    private final String nombre;
    private final List<Prueba> pruebas;

    public Cohete(int id, String nombre) {
        Objects.requireNonNull(nombre);
        validarId(id);
        this.id = id;
        this.nombre = nombre;
        pruebas = new ArrayList<>();
    }

    private static void validarId(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("Id invalido");
        }
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void agregarPrueba(Prueba nuevaPrueba) {
        Objects.requireNonNull(nuevaPrueba);
        pruebas.add(nuevaPrueba);
    }

    @Override
    public boolean aprueba() {
        boolean aprobado = true;
        Iterator<Prueba> it = pruebas.iterator();
        while (it.hasNext() && aprobado) {
            if (!it.next().aprueba()) {
                aprobado = false;
            }
        }
        return aprobado;
    }

}
