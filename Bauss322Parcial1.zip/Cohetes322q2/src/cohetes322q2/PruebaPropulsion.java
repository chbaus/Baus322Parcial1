package cohetes322q2;

import java.time.LocalDate;

public class PruebaPropulsion extends Prueba {

    private final double puntaje;
    private final int duracion;
    public static final double PUNTAJE_MIN = 0;
    public static final double PUNTAJE_MAX = 10;
    public static final double PUNTAJE_APROB = 6;
    public static final int DURACION_MAX = 90;

    public PruebaPropulsion(LocalDate fecha, double puntaje, int duracion) {
        super(fecha);
        validarDuracion(duracion);
        validarPuntaje(puntaje);
        this.puntaje = puntaje;
        this.duracion = duracion;
    }

    private static void validarPuntaje(double puntaje) {
        if (puntaje < PUNTAJE_MIN || puntaje > PUNTAJE_MAX) {
            throw new IllegalArgumentException("Puntaje invalido");
        }
    }

    private static void validarDuracion(int duracion) {
        if (duracion < 0) {
            throw new IllegalArgumentException("Duracion invalida");
        }
    }

    public double getPuntaje() {
        return puntaje;
    }

    public int getDuracion() {
        return duracion;
    }

    @Override
    public boolean aprueba() {
        return duracion <= DURACION_MAX && puntaje >= PUNTAJE_APROB;
    }

}
