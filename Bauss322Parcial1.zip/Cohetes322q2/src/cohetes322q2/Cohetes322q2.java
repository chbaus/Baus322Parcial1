package cohetes322q2;

import java.time.LocalDate;

public class Cohetes322q2 {

    public static void main(String[] args) {

        AgenciaAeroEspacial agencia = new AgenciaAeroEspacial("Space X");

        cargarCohetes(agencia);

        System.out.println(agencia.cantListosLanzar());

    }

    public static void cargarCohetes(AgenciaAeroEspacial a) {

        Cohete starship = new Cohete(1, "Starship");
        Cohete falcon = new Cohete(2, "Falcon 1");

        starship.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 7, 80));
        starship.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 10, 85));
        starship.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.ACEPTABLE));

        falcon.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 7, 70));
        falcon.agregarPrueba(new PruebaPropulsion(LocalDate.now(), 9, 90));
        falcon.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.EXCELENTE));
        falcon.agregarPrueba(new PruebaSistemas(LocalDate.now(), NivelEvaluacion.ACEPTABLE));

        a.agregarCohete(falcon);
        a.agregarCohete(starship);

    }

}
