package cohetes322q2;

public enum NivelEvaluacion {
    DEFICIENTE,
    MINIMO,
    ACEPTABLE,
    EXCELENTE
}
