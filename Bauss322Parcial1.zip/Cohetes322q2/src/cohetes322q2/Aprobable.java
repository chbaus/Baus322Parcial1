package cohetes322q2;

public interface Aprobable {

    boolean aprueba();

}
