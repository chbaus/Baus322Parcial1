package cohetes322q2;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class AgenciaAeroEspacial {

    private final String nombre;
    private final List<Cohete> cohetes;

    public AgenciaAeroEspacial(String nombre) {
        Objects.requireNonNull(nombre);
        this.nombre = nombre;
        cohetes = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }

    public void agregarCohete(Cohete nuevoCohete) {
        Objects.requireNonNull(nuevoCohete);
        cohetes.add(nuevoCohete);
    }

    public int cantListosLanzar() {
        int cantidad = 0;
        for (Cohete c : cohetes) {
            if (c.aprueba()) {
                cantidad++;
            }
        }
        return cantidad;
    }
    
    
}
