package cohetes322q2;


import java.time.LocalDate;
import java.util.Objects;

public abstract class Prueba implements Aprobable {

    private final LocalDate fecha;

    public Prueba(LocalDate fecha) {
        Objects.requireNonNull(fecha);
        this.fecha = fecha;
    }

    public LocalDate getFecha() {
        return fecha;
    }

}