package cohetes322q2;

import java.time.LocalDate;
import java.util.Objects;

public class PruebaSistemas extends Prueba {

    private final NivelEvaluacion nivel;
    public static final NivelEvaluacion NIVEL_APROB = NivelEvaluacion.ACEPTABLE;

    public PruebaSistemas(LocalDate fecha, NivelEvaluacion nivel) {
        super(fecha);
        Objects.requireNonNull(nivel);
        this.nivel = nivel;
    }

    public NivelEvaluacion getNivel() {
        return nivel;
    }

    @Override
    public boolean aprueba() {
        return nivel.ordinal() >= NIVEL_APROB.ordinal();
    }

}
